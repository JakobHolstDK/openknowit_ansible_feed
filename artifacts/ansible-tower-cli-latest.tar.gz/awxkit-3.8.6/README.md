awxkit
======

Python library that backs the provided `awx` command line client.

For more information on installing the CLI and building the docs on how to use it, look [here](./awxkit/cli/docs).
